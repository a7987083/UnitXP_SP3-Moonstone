# TaiYangShenDian V1.4.2-AURA0.3.0 source

This source package is the buildable Native runtime only. The old `Interface\\AddOns\\TaiYangShenDian` companion addon is intentionally not included because the process-lifetime runtime owns lifecycle inside the DLL.

Build from `build/build.sh`. The build remains x86 / WoW 1.12.1, `/nodefaultlib`, Windows subsystem 5.01, deterministic timestamp 0.

PLR2 delta from PLR1 is intentionally narrow and contained in `src/dllmain.cpp`:

- Removed the PLAYER lifecycle owner whitelist / compatibility branch (`VanillaHelpers.dll`, `Reliquary.dll`).
- Removed rejection of unrecognized PLAYER entry owners (`HOOK_CONFLICT_UNKNOWN_PLAYER_OWNER`).
- Removed owner-dependent selection of another module's detour destination.
- The runtime now calls MinHook directly on the fixed `WoW112::PLAYER_LOAD_SCRIPT_FUNCTIONS` entry, stores MinHook's trampoline in `g_playerNext`, and enables that hook.
- `PLAYER_LOAD_SCRIPT_FUNCTIONS` inspection remains observe-only for diagnostics; it no longer decides whether or where the PLAYER hook is installed.
- AuraEngine v0.3.0 uses automatic dual mode. With `nampower.dll` loaded it consumes Nampower Aura events and does not duplicate its three native Aura hooks. For `*_OTHER` events, target identity is now resolved through Nampower's `GetUnitGUID("target")`, with the client object GUID used only as fallback. Without Nampower it validates the original WoW 5875 prologues and installs standalone hooks for Aura add/remove/stack changes.
- Corrected the unit-field pointer and Aura layout to `unit+0x110`, Aura `0x29`, packed-nibble flags `0x59`, levels `0x5F`, applications `0x6B`, with displayed stacks converted from zero-based storage by `+1`.
- Added `Aura.Mode` and `Aura.Find(unit, spellID)`. Existing commands and default-player behavior remain compatible.
- Fixed target poison updates that were only visible after an explicit `Aura.Find`: target add/remove/stack events no longer depend on a fragile object GUID offset comparison.
- API version remains 15. All DBC, Visual, MoonMarker, Profiler, DreamAvatar, DreamWeapon and addon-facing API behavior is otherwise unchanged.
