# TaiYangShenDian AuraEngine v0.2.0

## Automatic modes

`Aura.Mode` returns five values:

```lua
local mode, nampowerDetected, nampowerEventsReady, nativeHookReady, detail =
    TaiYangShenDian("Aura.Mode")
```

- `NAMPOWER_EVENTS`: Nampower is loaded. The DLL receives its eight Buff/Debuff events and does not hook the same native entries.
- `STANDALONE_NATIVE_HOOK`: Nampower is absent. The DLL owns the three Aura add/remove/stack hooks.
- `PASSIVE_UNIT_AURA`: an entry is already modified or hook installation failed; only the safe hidden-frame `UNIT_AURA` path remains.
- `NAMPOWER_PASSIVE`: Nampower is present but its custom events could not be registered; no duplicate hook is attempted.

## Correct client layout

- UnitFields pointer: unit object `+0x110`
- Aura spell IDs: relative dword `0x29`, 48 entries
- Aura flags: relative dword `0x59`, two 4-bit nibbles per byte
- Aura levels: relative dword `0x5F`, 48 bytes
- Aura applications: relative dword `0x6B`, 48 bytes
- Displayed stack: stored applications `+1` while the slot contains a spell
- Buff slots: raw `0..31`
- Debuff slots: raw `32..47`

## Commands

```lua
TaiYangShenDian("Aura.Mode")
TaiYangShenDian("Aura.Status", "player")
TaiYangShenDian("Aura.Status", "target")
TaiYangShenDian("Aura.SetCallback", callback)
TaiYangShenDian("Aura.Refresh", "target")
TaiYangShenDian("Aura.Get", "target", rawSlot)
TaiYangShenDian("Aura.Find", "target", spellID)
TaiYangShenDian("Aura.Snapshot", "target")
TaiYangShenDian("Aura.Reset")
```

Callback events remain:

- `AURA_ADDED`
- `AURA_REMOVED`
- `AURA_UPDATED`
- `AURA_STACK_CHANGED`

The Aura table adds `sourceMode`; all v0.1.1 fields remain.

## Compatibility rules

- Never install standalone Aura hooks when `nampower.dll` is detected.
- Never follow or overwrite an unknown entry jump.
- Nampower events are filtered to `player` and the current `target` by unit GUID.
- Snapshot reads initialize caches and provide explicit validation; there is no polling.
