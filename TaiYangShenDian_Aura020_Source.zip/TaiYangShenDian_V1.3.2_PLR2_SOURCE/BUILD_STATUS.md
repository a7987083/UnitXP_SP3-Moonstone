# V1.4.0-AURA0.2.0 build status

Implementation is complete for automatic Nampower/Standalone dual mode, corrected WoW 5875 Aura layout, custom spell-ID lookup, and the DreamWeapon-style companion diagnostic addon.

Final x86 DLL build and PE verification are pending GitHub Actions. See `BUILD_STATUS_V020.md` for the detailed checklist.
