# V1.4.0-AURA0.2.0 build status

## Implemented

- Preserved the V1.3.2-PLR2/API 15 compatibility baseline.
- Added automatic Nampower/Standalone dual mode.
- Nampower mode registers the eight `BUFF_*` / `DEBUFF_*` events and installs no duplicate Aura hook.
- Standalone mode validates original Build 5875 prologues before installing add/remove/stack hooks.
- Unknown pre-existing entry modification produces `PASSIVE_UNIT_AURA`, never an overwrite.
- Corrected UnitFields pointer, Aura IDs, packed flags, levels and stack offsets.
- Corrected zero-based stored applications to one-based displayed stack count.
- Added `Aura.Mode` and `Aura.Find` while retaining every v0.1.1 command.
- Added DreamWeapon-style `TaiYangAura` companion/diagnostic addon with custom spell-ID filtering.
- No worker thread, timer, addon `OnUpdate`, per-frame scan or new render hook.

## Build verification

Pending GitHub Actions x86 build and artifact verification.

Real-machine acceptance inside Turtle WoW remains required before Stable freeze.
