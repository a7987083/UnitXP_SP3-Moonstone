# TaiYangShenDian AuraEngine v0.1

## Runtime behavior

The DLL registers the optional `UNIT_AURA` event on its existing hidden
process-lifetime frame. When that event arrives, the native reader reads the
player's 48 update-field Aura slots, compares them with the previous cache and
publishes only changes.

Events:

- `AURA_ADDED`
- `AURA_REMOVED`
- `AURA_UPDATED`
- `AURA_STACK_CHANGED`

The event callback is registered from Lua:

```lua
TaiYangShenDian("Aura.SetCallback", function(eventName, unit, aura)
    DEFAULT_CHAT_FRAME:AddMessage(eventName .. " spellID=" .. aura.spellID)
end)
```

The callback receives `eventName`, `"player"`, and an Aura table containing:
`spellID`, `slot`, `flags`, `level`, `applications`, `stack`, `casterGUID`,
`duration`, and `expiration`.

## Lua commands

```lua
TaiYangShenDian("Aura.Status")                 -- enabled, status, count, ready
TaiYangShenDian("Aura.SetCallback", callback)  -- starts from current state
TaiYangShenDian("Aura.Refresh", "player")
TaiYangShenDian("Aura.Get", "player", slot)
TaiYangShenDian("Aura.Snapshot", "player")
TaiYangShenDian("Aura.Reset")
```

This first release intentionally supports the player only. `casterGUID`,
`duration`, and `expiration` are returned as zero because those values are not
present in the WoW 1.12 unit update-field Aura array. They must be added later
from the client Aura application structure or packet/update path; the cache and
event ABI already expose the fields.

No worker thread, timer, per-frame scan, or new render hook is installed.
