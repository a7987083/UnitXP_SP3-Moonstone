# TaiYangShenDian AuraEngine v0.1.1

## Runtime behavior

The DLL registers `UNIT_AURA` and `PLAYER_TARGET_CHANGED` on its existing
hidden process-lifetime frame. `UNIT_AURA` uses its unit token when available,
so only the changed `player` or `target` 48-slot cache is read and diffed.

Supported units:

- `player`: self Buffs and self Debuffs
- `target`: target Buffs and target Debuffs, including stackable rogue poisons

Events:

- `AURA_ADDED`
- `AURA_REMOVED`
- `AURA_UPDATED`
- `AURA_STACK_CHANGED`

The callback receives `eventName`, unit (`"player"` or `"target"`), and an Aura
table containing `spellID`, `slot`, `flags`, `level`, `applications`, `stack`,
`casterGUID`, `duration`, `expiration`, `auraType`, and `isDebuff`.

Slots `0..31` are exposed as `BUFF`; slots `32..47` are exposed as `DEBUFF`.

```lua
TaiYangShenDian("Aura.SetCallback", function(eventName, unit, aura)
    DEFAULT_CHAT_FRAME:AddMessage(unit .. " " .. eventName .. " spellID=" .. aura.spellID)
end)
```

## Lua commands

```lua
TaiYangShenDian("Aura.Status", "player")
TaiYangShenDian("Aura.Status", "target")
TaiYangShenDian("Aura.SetCallback", callback)
TaiYangShenDian("Aura.Refresh", "player")
TaiYangShenDian("Aura.Refresh", "target")
TaiYangShenDian("Aura.Get", "target", slot)
TaiYangShenDian("Aura.Snapshot", "target")
TaiYangShenDian("Aura.Reset")
```

Omitting the unit keeps backward compatibility and defaults to `player`.
Unsupported unit tokens return `UNIT_NOT_SUPPORTED`.

`casterGUID`, `duration`, and `expiration` remain zero because those values are
not present in the WoW 1.12 unit update-field Aura array.

No worker thread, timer, per-frame scan, `OnUpdate`, polling loop, or new render
hook is installed.
