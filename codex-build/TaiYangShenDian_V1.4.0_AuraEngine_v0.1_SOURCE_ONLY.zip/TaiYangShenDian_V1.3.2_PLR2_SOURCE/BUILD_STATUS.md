# V1.4.0-AURA0.1 build status

## Completed

- PLR2 source retained as the compatibility baseline.
- Added `src/aura_engine.cpp` and `src/aura_engine.h`.
- Added the player-only 48-slot Aura reader and cache diff engine.
- Added `Aura.Status`, `Aura.SetCallback`, `Aura.Refresh`, `Aura.Get`,
  `Aura.Snapshot`, and `Aura.Reset`.
- Registered optional `UNIT_AURA` handling on the existing hidden lifecycle
  frame without adding a worker thread, timer, OnUpdate loop, or render hook.
- Updated the build script and API documentation.
- C++ syntax/type checks passed with the available GCC compatibility check.
- `bash -n build/build.sh` passed.

## DLL link status

The final PE DLL was not rebuilt in this Linux workspace because the source's
required toolchain is `clang-cl` plus `lld-link`, and neither executable is
installed here. The DLL in the parent PLR2 package remains the unchanged
V1.3.2-PLR2 binary and must not be described as containing AuraEngine.

Build on the Windows x86 toolchain with:

```text
cd Source/TaiYangShenDian_V1.3.2_PLR2_SOURCE
bash build/build.sh
```

Expected output is `taiyangshendian.dll` with version `1.4.0-AURA0.1`, API 15,
and build ID `20260824-v140-aura01-direct-minhook-runtime`.
