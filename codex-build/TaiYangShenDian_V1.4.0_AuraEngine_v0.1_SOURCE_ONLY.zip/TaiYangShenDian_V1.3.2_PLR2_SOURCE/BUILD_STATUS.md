# V1.4.0-AURA0.1.1 build status

## Implemented

- Preserved the V1.3.2-PLR2/API 15 compatibility baseline.
- Expanded AuraEngine from player-only to separate `player` and `target` caches.
- Supports Buff and Debuff slots for both units.
- Added target poison stack diagnostics through `AURA_STACK_CHANGED`.
- Added `PLAYER_TARGET_CHANGED` handling to the existing hidden lifecycle frame.
- `UNIT_AURA` refreshes only its reported unit when `arg1` is available.
- Kept all existing `Aura.*` command names; omitted unit still defaults to player.
- Added no worker thread, timer, OnUpdate loop, polling loop, or render hook.

## Pre-build checks

- AuraEngine C++ syntax/type check: PASS.
- Lua 5.x syntax parse: PASS.
- WoW 1.12 UI/native stub test with target poison stack change: PASS.
- `bash -n build/build.sh`: PASS.

The final x86 PE hash and size are recorded after GitHub Actions compilation.
