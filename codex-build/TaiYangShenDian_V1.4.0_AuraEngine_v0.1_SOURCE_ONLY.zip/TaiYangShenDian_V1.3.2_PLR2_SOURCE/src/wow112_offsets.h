#pragma once
namespace WoW112 {
constexpr unsigned long IMAGE_BASE = 0x00400000UL;
constexpr unsigned long PE_TIMESTAMP = 0x4510B6DBUL;
constexpr unsigned short MACHINE_I386 = 0x014c;
constexpr unsigned short PE32_MAGIC = 0x010b;

constexpr unsigned long PLAYER_LOAD_SCRIPT_FUNCTIONS = 0x00490250UL;
constexpr unsigned long GLUE_LOAD_SCRIPT_FUNCTIONS   = 0x0046ABB0UL;
constexpr unsigned long FRAME_SCRIPT_REGISTER_FUNCTION = 0x00704120UL;
constexpr unsigned long RESOLVE_UNIT_TOKEN = 0x00515940UL;
constexpr unsigned long MOVEMENT_GET_EFFECTIVE_SPEED = 0x007C4C90UL;
constexpr unsigned long UNIT_REACTION = 0x006061E0UL;
constexpr unsigned long CAN_ATTACK = 0x00606980UL;
constexpr unsigned long UNIT_GET_CREATURE_TYPE = 0x00605570UL;
constexpr unsigned long OBJECT_MANAGER_PTR = 0x00B41414UL;

constexpr unsigned long LUA_STATE_PTR = 0x007040D0UL;
constexpr unsigned long LUA_GETTOP = 0x006F3070UL;
constexpr unsigned long LUA_SETTOP = 0x006F3080UL;
constexpr unsigned long LUA_TYPE = 0x006F3400UL;
constexpr unsigned long LUA_ISNUMBER = 0x006F34D0UL;
constexpr unsigned long LUA_ISSTRING = 0x006F3510UL;
constexpr unsigned long LUA_TONUMBER = 0x006F3620UL;
constexpr unsigned long LUA_TOBOOLEAN = 0x006F3660UL;
constexpr unsigned long LUA_TOSTRING = 0x006F3690UL;
constexpr unsigned long LUA_PUSHNIL = 0x006F37F0UL;
constexpr unsigned long LUA_PUSHNUMBER = 0x006F3810UL;
constexpr unsigned long LUA_PUSHSTRING = 0x006F3890UL;
constexpr unsigned long LUA_PUSHBOOLEAN = 0x006F39F0UL;
constexpr unsigned long LUA_GETTABLE = 0x006F3A40UL;
constexpr unsigned long LUA_NEWTABLE = 0x006F3C90UL;
constexpr unsigned long LUA_SETTABLE = 0x006F3E20UL;
constexpr unsigned long LUA_ISCFUNCTION = 0x006F34A0UL;
constexpr unsigned long LUA_TOCFUNCTION = 0x006F3720UL;
constexpr unsigned long LUA_PCALL = 0x006F41A0UL;
constexpr unsigned long LUA_PUSHVALUE = 0x006F3350UL;
constexpr unsigned long LUA_INSERT = 0x006F31A0UL;
constexpr unsigned long LUA_PUSHCLOSURE = 0x006F3920UL;
constexpr unsigned long LUA_CALL = 0x006F4180UL;
constexpr unsigned long LUA_SEThOOK = 0x006FBA40UL;
constexpr unsigned long LUA_GETINFO = 0x006FBAA0UL;
constexpr unsigned long LUA_GETSTACK = 0x006FBB20UL;

// Lua 5.0 lua_State hook fields used by the original B1R5R4 Targeted Deep implementation.
constexpr unsigned long OFF_LUA_HOOK_MASK = 0x30UL;
constexpr unsigned long OFF_LUA_HOOK_PTR = 0x3CUL;

constexpr int LUA_GLOBALSINDEX = -10001;
constexpr int LUA_UPVALUE1 = -10002;
constexpr int LUA_UPVALUE2 = -10003;
constexpr int LUA_TFUNCTION = 6;

constexpr unsigned long OFF_UNIT_MOVEMENT_INFO_PTR = 0x118UL;
constexpr unsigned long OFF_MOVEMENT_FACING = 0x1CUL;
constexpr unsigned long OFF_MOVEMENT_RUN_SPEED = 0x8CUL;
constexpr unsigned long OFF_MOVEMENT_SWIM_SPEED = 0x94UL;

constexpr unsigned long OFF_CGOBJECT_DESCRIPTOR = 0x08UL;
constexpr unsigned long OFF_CGOBJECT_TYPE = 0x14UL;
constexpr unsigned long OFF_CGOBJECT_GUID = 0x30UL;
constexpr unsigned long OFF_CGOBJECT_VTBL_GET_POSITION = 0x14UL; // vtable slot 5
constexpr unsigned long OFF_OBJECT_FIELD_ENTRY = 0x0CUL;

constexpr unsigned long OFF_OBJECT_MANAGER_NEXT_BASE = 0xA4UL;
constexpr unsigned long OFF_OBJECT_MANAGER_HEAD = 0xACUL;

// DynamicObject UpdateFields relative to the generic descriptor pointer.
constexpr unsigned long OFF_DYNAMIC_CASTER_GUID = 0x18UL;
constexpr unsigned long OFF_DYNAMIC_SPELL_ID = 0x24UL;
constexpr unsigned long OFF_DYNAMIC_RADIUS = 0x28UL;
constexpr unsigned long OFF_DYNAMIC_X = 0x2CUL;
constexpr unsigned long OFF_DYNAMIC_Y = 0x30UL;
constexpr unsigned long OFF_DYNAMIC_Z = 0x34UL;

constexpr unsigned long TYPE_UNIT = 3UL;
constexpr unsigned long TYPE_PLAYER = 4UL;
constexpr unsigned long TYPE_GAMEOBJECT = 5UL;
constexpr unsigned long TYPE_DYNAMICOBJECT = 6UL;
}
