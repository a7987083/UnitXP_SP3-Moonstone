#pragma once

#include "lua50.h"

namespace TysAura {
    void reset();
    void onEvent(Lua50::State L, const char* eventName, const char* unitToken = 0);
    int dispatch(Lua50::State L, const char* command);
    const char* status();
    unsigned count();
}
