#include <windows.h>
#include "aura_engine.h"

namespace TysAura {

constexpr unsigned long OBJECT_DESCRIPTOR = 0x08UL;
constexpr unsigned long UNIT_AURA_FIRST = 0x2FUL;
constexpr unsigned long UNIT_AURA_COUNT = 48UL;
constexpr unsigned long UNIT_AURA_FLAGS = 0x5FUL;
constexpr unsigned long UNIT_AURA_LEVELS = 0x6BUL;
constexpr unsigned long UNIT_AURA_APPLICATIONS = 0x77UL;
constexpr unsigned long RESOLVE_UNIT_TOKEN = 0x00515940UL;
constexpr int LUA_GLOBALSINDEX = -10001;
constexpr int LUA_TFUNCTION = 6;
constexpr int AURA_UNIT_PLAYER = 0;
constexpr int AURA_UNIT_TARGET = 1;
constexpr int AURA_UNIT_COUNT = 2;

using ResolveUnitFn = void* (__fastcall *)(const char*);

struct AuraInfo {
    unsigned long spellId;
    unsigned long slot;
    unsigned char flags;
    unsigned char level;
    unsigned char applications;
    unsigned char reserved;
    unsigned long long casterGuid;
    unsigned long durationMs;
    unsigned long expirationMs;
};

static AuraInfo g_cache[AURA_UNIT_COUNT][UNIT_AURA_COUNT] = {};
static bool g_ready[AURA_UNIT_COUNT] = {};
static char g_status[AURA_UNIT_COUNT][96] = {"NOT_INITIALIZED", "NOT_INITIALIZED"};
static unsigned g_count[AURA_UNIT_COUNT] = {};

static bool textEquals(const char* left, const char* right) {
    if (!left || !right) return false;
    unsigned long i = 0;
    while (left[i] && right[i] && left[i] == right[i]) ++i;
    return left[i] == 0 && right[i] == 0;
}

static const char* unitName(int unit) {
    return unit == AURA_UNIT_TARGET ? "target" : "player";
}

static int unitIndex(const char* token) {
    if (!token) return -1;
    if (textEquals(token, "player")) return AURA_UNIT_PLAYER;
    if (textEquals(token, "target")) return AURA_UNIT_TARGET;
    return -1;
}

static int luaUnitIndex(Lua50::State L, int index) {
    if (Lua50::GetTop(L) < index) return AURA_UNIT_PLAYER;
    if (!Lua50::IsString(L, index)) return -1;
    return unitIndex(Lua50::ToString(L, index));
}

static bool readable(const void* address, unsigned long size) {
    if (!address || !size) return false;
    MEMORY_BASIC_INFORMATION m = {};
    if (VirtualQuery(address, &m, sizeof(m)) != sizeof(m)) return false;
    if (m.State != MEM_COMMIT) return false;
    DWORD protection = m.Protect & 0xFF;
    if (protection == PAGE_NOACCESS || protection == PAGE_EXECUTE) return false;
    unsigned long begin = (unsigned long)address;
    unsigned long end = (unsigned long)m.BaseAddress + (unsigned long)m.RegionSize;
    return end >= begin && size <= end - begin;
}

static void copyText(char* out, unsigned long capacity, const char* text) {
    if (!out || !capacity) return;
    unsigned long i = 0;
    if (text) while (text[i] && i + 1 < capacity) { out[i] = text[i]; ++i; }
    out[i] = 0;
}

static void clearInfo(AuraInfo* info, unsigned long slot) {
    if (!info) return;
    info->spellId = 0; info->slot = slot; info->flags = 0; info->level = 0;
    info->applications = 0; info->reserved = 0; info->casterGuid = 0;
    info->durationMs = 0; info->expirationMs = 0;
}

static void clearUnitCache(int unit) {
    if (unit < 0 || unit >= AURA_UNIT_COUNT) return;
    for (unsigned long i = 0; i < UNIT_AURA_COUNT; ++i) clearInfo(&g_cache[unit][i], i);
    g_ready[unit] = false; g_count[unit] = 0;
}

static void clearAllCaches() {
    clearUnitCache(AURA_UNIT_PLAYER);
    clearUnitCache(AURA_UNIT_TARGET);
}

static void* unitObject(int unit) {
    if (!readable((void*)RESOLVE_UNIT_TOKEN, 1)) return 0;
    return ((ResolveUnitFn)RESOLVE_UNIT_TOKEN)(unitName(unit));
}

static bool descriptor(void* object, unsigned char** out) {
    if (!object || !out || !readable((unsigned char*)object + OBJECT_DESCRIPTOR, 4)) return false;
    unsigned char* d = *(unsigned char**)((unsigned char*)object + OBJECT_DESCRIPTOR);
    if (!d || !readable(d, (UNIT_AURA_APPLICATIONS + 12UL) * 4UL)) return false;
    *out = d; return true;
}

static bool readDword(unsigned char* d, unsigned long field, unsigned long* out) {
    if (!d || !out || !readable(d + field * 4UL, 4)) return false;
    *out = *(unsigned long*)(d + field * 4UL); return true;
}

static bool readByte(unsigned char* d, unsigned long field, unsigned long slot, unsigned char* out) {
    if (!d || !out || !readable(d + field * 4UL + slot, 1)) return false;
    *out = *(unsigned char*)(d + field * 4UL + slot); return true;
}

static bool readSnapshot(int unit, AuraInfo* out, unsigned* activeCount) {
    if (unit < 0 || unit >= AURA_UNIT_COUNT || !out || !activeCount) return false;
    unsigned char* d = 0; void* object = unitObject(unit);
    if (!object || !descriptor(object, &d)) return false;
    unsigned active = 0;
    for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) {
        AuraInfo info = {}; clearInfo(&info, slot);
        if (!readDword(d, UNIT_AURA_FIRST + slot, &info.spellId)) return false;
        if (!readByte(d, UNIT_AURA_FLAGS, slot, &info.flags)) return false;
        if (!readByte(d, UNIT_AURA_LEVELS, slot, &info.level)) return false;
        if (!readByte(d, UNIT_AURA_APPLICATIONS, slot, &info.applications)) return false;
        if (info.spellId) ++active;
        out[slot] = info;
    }
    *activeCount = active; return true;
}

static bool sameInfo(const AuraInfo& a, const AuraInfo& b) {
    return a.spellId == b.spellId && a.flags == b.flags && a.level == b.level && a.applications == b.applications;
}

static void setField(Lua50::State L, const char* key, double value) {
    Lua50::PushString(L, key); Lua50::PushNumber(L, value); Lua50::SetTable(L, -3);
}

static void setField(Lua50::State L, const char* key, const char* value) {
    Lua50::PushString(L, key); Lua50::PushString(L, value); Lua50::SetTable(L, -3);
}

static void setBoolField(Lua50::State L, const char* key, bool value) {
    Lua50::PushString(L, key); Lua50::PushBool(L, value); Lua50::SetTable(L, -3);
}

static void pushInfo(Lua50::State L, int unit, const AuraInfo& info) {
    const bool isDebuff = info.slot >= 32UL;
    Lua50::NewTable(L);
    setField(L, "unit", unitName(unit)); setField(L, "spellID", (double)info.spellId);
    setField(L, "slot", (double)info.slot); setField(L, "flags", (double)info.flags);
    setField(L, "level", (double)info.level); setField(L, "applications", (double)info.applications);
    setField(L, "stack", (double)info.applications); setField(L, "casterGUID", (double)info.casterGuid);
    setField(L, "duration", (double)info.durationMs / 1000.0); setField(L, "expiration", (double)info.expirationMs / 1000.0);
    setField(L, "auraType", isDebuff ? "DEBUFF" : "BUFF"); setBoolField(L, "isDebuff", isDebuff);
}

static void invokeCallback(Lua50::State L, const char* eventName, int unit, const AuraInfo& info) {
    if (!L || !eventName) return;
    int top = Lua50::GetTop(L); Lua50::GetGlobal(L, "TaiYangShenDian_AuraCallback");
    if (Lua50::Type(L, -1) != LUA_TFUNCTION) { Lua50::SetTop(L, top); return; }
    Lua50::PushString(L, eventName); Lua50::PushString(L, unitName(unit)); pushInfo(L, unit, info);
    Lua50::PCall(L, 3, 0, 0); Lua50::SetTop(L, top);
}

static bool syncUnit(Lua50::State L, int unit, bool emit) {
    if (unit < 0 || unit >= AURA_UNIT_COUNT) return false;
    AuraInfo next[UNIT_AURA_COUNT] = {}; unsigned nextCount = 0;
    if (!readSnapshot(unit, next, &nextCount)) {
        if (unit == AURA_UNIT_TARGET) clearUnitCache(unit);
        copyText(g_status[unit], sizeof(g_status[unit]), unit == AURA_UNIT_TARGET ? "TARGET_AURA_UNAVAILABLE" : "PLAYER_AURA_UNAVAILABLE");
        return false;
    }
    if (!g_ready[unit]) {
        for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) {
            if (emit && next[slot].spellId) invokeCallback(L, "AURA_ADDED", unit, next[slot]);
            g_cache[unit][slot] = next[slot];
        }
        g_ready[unit] = true; g_count[unit] = nextCount; copyText(g_status[unit], sizeof(g_status[unit]), "READY_EVENT_DRIVEN"); return true;
    }
    for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) {
        const AuraInfo& oldInfo = g_cache[unit][slot]; const AuraInfo& newInfo = next[slot];
        if (!oldInfo.spellId && newInfo.spellId) { if (emit) invokeCallback(L, "AURA_ADDED", unit, newInfo); }
        else if (oldInfo.spellId && !newInfo.spellId) { if (emit) invokeCallback(L, "AURA_REMOVED", unit, oldInfo); }
        else if (oldInfo.spellId && newInfo.spellId) {
            if (oldInfo.applications != newInfo.applications) { if (emit) invokeCallback(L, "AURA_STACK_CHANGED", unit, newInfo); }
            else if (!sameInfo(oldInfo, newInfo)) { if (emit) invokeCallback(L, "AURA_UPDATED", unit, newInfo); }
        }
        g_cache[unit][slot] = newInfo;
    }
    g_count[unit] = nextCount; copyText(g_status[unit], sizeof(g_status[unit]), "READY_EVENT_DRIVEN"); return true;
}

static int doStatus(Lua50::State L) {
    const int unit = luaUnitIndex(L, 2);
    if (unit < 0) { Lua50::PushBool(L, false); Lua50::PushString(L, "UNIT_NOT_SUPPORTED"); Lua50::PushNumber(L, 0); Lua50::PushBool(L, false); return 4; }
    Lua50::PushBool(L, true); Lua50::PushString(L, g_status[unit]); Lua50::PushNumber(L, (double)g_count[unit]); Lua50::PushBool(L, g_ready[unit]); return 4;
}

static int doSetCallback(Lua50::State L) {
    int callbackType = Lua50::GetTop(L) >= 2 ? Lua50::Type(L, 2) : 0;
    if (callbackType != LUA_TFUNCTION && callbackType != 0) { Lua50::PushBool(L, false); Lua50::PushString(L, "CALLBACK_MUST_BE_FUNCTION"); return 2; }
    if (callbackType == 0) Lua50::PushNil(L); else Lua50::PushValue(L, 2);
    Lua50::PushString(L, "TaiYangShenDian_AuraCallback"); Lua50::Insert(L, -2); Lua50::SetTable(L, LUA_GLOBALSINDEX);
    if (callbackType == LUA_TFUNCTION) {
        clearAllCaches(); syncUnit(L, AURA_UNIT_PLAYER, true); syncUnit(L, AURA_UNIT_TARGET, true);
    }
    Lua50::PushBool(L, true); Lua50::PushString(L, "OK"); return 2;
}

static int doRefresh(Lua50::State L) {
    const int unit = luaUnitIndex(L, 2);
    if (unit < 0) { Lua50::PushBool(L, false); Lua50::PushString(L, "UNIT_NOT_SUPPORTED"); return 2; }
    syncUnit(L, unit, true); Lua50::PushBool(L, g_ready[unit]); Lua50::PushString(L, g_status[unit]); Lua50::PushNumber(L, (double)g_count[unit]); return 3;
}

static int doGet(Lua50::State L) {
    const int unit = luaUnitIndex(L, 2);
    if (unit < 0 || Lua50::GetTop(L) < 3 || !Lua50::IsNumber(L, 3)) { Lua50::PushNil(L); Lua50::PushString(L, "BAD_ARGUMENT"); return 2; }
    syncUnit(L, unit, false); long slot = (long)Lua50::ToNumber(L, 3);
    if (slot < 0 || slot >= (long)UNIT_AURA_COUNT || !g_cache[unit][slot].spellId) { Lua50::PushNil(L); Lua50::PushString(L, "AURA_NOT_FOUND"); return 2; }
    pushInfo(L, unit, g_cache[unit][slot]); return 1;
}

static int doSnapshot(Lua50::State L) {
    const int unit = luaUnitIndex(L, 2);
    if (unit < 0) { Lua50::PushNil(L); Lua50::PushString(L, "UNIT_NOT_SUPPORTED"); return 2; }
    syncUnit(L, unit, false); Lua50::NewTable(L); int arrayIndex = 1;
    for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) if (g_cache[unit][slot].spellId) {
        Lua50::PushNumber(L, (double)arrayIndex++); pushInfo(L, unit, g_cache[unit][slot]); Lua50::SetTable(L, -3);
    }
    return 1;
}

void reset() {
    clearAllCaches();
    copyText(g_status[AURA_UNIT_PLAYER], sizeof(g_status[AURA_UNIT_PLAYER]), "RESET");
    copyText(g_status[AURA_UNIT_TARGET], sizeof(g_status[AURA_UNIT_TARGET]), "RESET");
}

void onEvent(Lua50::State L, const char* eventName, const char* unitToken) {
    if (!eventName) return;
    if (textEquals(eventName, "PLAYER_LEAVING_WORLD") || textEquals(eventName, "PLAYER_ENTERING_WORLD")) { reset(); return; }
    if (textEquals(eventName, "PLAYER_TARGET_CHANGED")) {
        clearUnitCache(AURA_UNIT_TARGET); copyText(g_status[AURA_UNIT_TARGET], sizeof(g_status[AURA_UNIT_TARGET]), "TARGET_CHANGED");
        syncUnit(L, AURA_UNIT_TARGET, true); return;
    }
    if (!textEquals(eventName, "UNIT_AURA")) return;
    const int unit = unitIndex(unitToken);
    if (unit >= 0) syncUnit(L, unit, true);
    else { syncUnit(L, AURA_UNIT_PLAYER, true); syncUnit(L, AURA_UNIT_TARGET, true); }
}

int dispatch(Lua50::State L, const char* command) {
    if (!command || command[0] != 'A' || command[1] != 'u' || command[2] != 'r' || command[3] != 'a' || command[4] != '.') return -1;
    if (command[5] == 'S' && command[6] == 't' && command[7] == 'a' && command[8] == 't' && command[9] == 'u' && command[10] == 's' && command[11] == 0) return doStatus(L);
    if (command[5] == 'S' && command[6] == 'e' && command[7] == 't' && command[8] == 'C' && command[9] == 'a' && command[10] == 'l' && command[11] == 'l' && command[12] == 'b' && command[13] == 'a' && command[14] == 'c' && command[15] == 'k' && command[16] == 0) return doSetCallback(L);
    if (command[5] == 'R' && command[6] == 'e' && command[7] == 'f' && command[8] == 'r' && command[9] == 'e' && command[10] == 's' && command[11] == 'h' && command[12] == 0) return doRefresh(L);
    if (command[5] == 'G' && command[6] == 'e' && command[7] == 't' && command[8] == 0) return doGet(L);
    if (command[5] == 'S' && command[6] == 'n' && command[7] == 'a' && command[8] == 'p' && command[9] == 's' && command[10] == 'h' && command[11] == 'o' && command[12] == 't' && command[13] == 0) return doSnapshot(L);
    if (command[5] == 'R' && command[6] == 'e' && command[7] == 's' && command[8] == 'e' && command[9] == 't' && command[10] == 0) { reset(); Lua50::PushBool(L, true); return 1; }
    return -1;
}

const char* status() { return g_status[AURA_UNIT_PLAYER]; }
unsigned count() { return g_count[AURA_UNIT_PLAYER] + g_count[AURA_UNIT_TARGET]; }

}
