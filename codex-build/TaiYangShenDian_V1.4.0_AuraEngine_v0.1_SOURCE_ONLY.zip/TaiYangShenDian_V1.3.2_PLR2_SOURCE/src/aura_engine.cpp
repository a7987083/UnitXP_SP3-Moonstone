#include <windows.h>
#include "aura_engine.h"

namespace TysAura {

constexpr unsigned long OBJECT_DESCRIPTOR = 0x08UL;
constexpr unsigned long UNIT_AURA_FIRST = 0x2FUL;
constexpr unsigned long UNIT_AURA_COUNT = 48UL;
constexpr unsigned long UNIT_AURA_FLAGS = 0x5FUL;
constexpr unsigned long UNIT_AURA_LEVELS = 0x6BUL;
constexpr unsigned long UNIT_AURA_APPLICATIONS = 0x77UL;
constexpr unsigned long RESOLVE_UNIT_TOKEN = 0x00515940UL;
constexpr int LUA_GLOBALSINDEX = -10001;
constexpr int LUA_TFUNCTION = 6;

using ResolveUnitFn = void* (__fastcall *)(const char*);

struct AuraInfo {
    unsigned long spellId;
    unsigned long slot;
    unsigned char flags;
    unsigned char level;
    unsigned char applications;
    unsigned char reserved;
    unsigned long long casterGuid;
    unsigned long durationMs;
    unsigned long expirationMs;
};

static AuraInfo g_cache[UNIT_AURA_COUNT] = {};
static bool g_ready = false;
static char g_status[96] = "NOT_INITIALIZED";
static unsigned g_count = 0;

static bool readable(const void* address, unsigned long size) {
    if (!address || !size) return false;
    MEMORY_BASIC_INFORMATION m = {};
    if (VirtualQuery(address, &m, sizeof(m)) != sizeof(m)) return false;
    if (m.State != MEM_COMMIT) return false;
    DWORD protection = m.Protect & 0xFF;
    if (protection == PAGE_NOACCESS || protection == PAGE_EXECUTE) return false;
    unsigned long begin = (unsigned long)address;
    unsigned long end = (unsigned long)m.BaseAddress + (unsigned long)m.RegionSize;
    return end >= begin && size <= end - begin;
}

static void copyText(char* out, unsigned long capacity, const char* text) {
    if (!out || !capacity) return;
    unsigned long i = 0;
    if (text) while (text[i] && i + 1 < capacity) { out[i] = text[i]; ++i; }
    out[i] = 0;
}

static void clearInfo(AuraInfo* info, unsigned long slot) {
    if (!info) return;
    info->spellId = 0; info->slot = slot; info->flags = 0; info->level = 0;
    info->applications = 0; info->reserved = 0; info->casterGuid = 0;
    info->durationMs = 0; info->expirationMs = 0;
}

static void clearCache() {
    for (unsigned long i = 0; i < UNIT_AURA_COUNT; ++i) clearInfo(&g_cache[i], i);
    g_ready = false; g_count = 0;
}

static void* playerObject() {
    if (!readable((void*)RESOLVE_UNIT_TOKEN, 1)) return 0;
    return ((ResolveUnitFn)RESOLVE_UNIT_TOKEN)("player");
}

static bool descriptor(void* object, unsigned char** out) {
    if (!object || !out || !readable((unsigned char*)object + OBJECT_DESCRIPTOR, 4)) return false;
    unsigned char* d = *(unsigned char**)((unsigned char*)object + OBJECT_DESCRIPTOR);
    if (!d || !readable(d, (UNIT_AURA_APPLICATIONS + 12UL) * 4UL)) return false;
    *out = d; return true;
}

static bool readDword(unsigned char* d, unsigned long field, unsigned long* out) {
    if (!d || !out || !readable(d + field * 4UL, 4)) return false;
    *out = *(unsigned long*)(d + field * 4UL); return true;
}

static bool readByte(unsigned char* d, unsigned long field, unsigned long slot, unsigned char* out) {
    if (!d || !out || !readable(d + field * 4UL + slot, 1)) return false;
    *out = *(unsigned char*)(d + field * 4UL + slot); return true;
}

static bool readSnapshot(AuraInfo* out, unsigned* activeCount) {
    if (!out || !activeCount) return false;
    unsigned char* d = 0; void* object = playerObject();
    if (!object || !descriptor(object, &d)) return false;
    unsigned active = 0;
    for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) {
        AuraInfo info = {}; clearInfo(&info, slot);
        if (!readDword(d, UNIT_AURA_FIRST + slot, &info.spellId)) return false;
        if (!readByte(d, UNIT_AURA_FLAGS, slot, &info.flags)) return false;
        if (!readByte(d, UNIT_AURA_LEVELS, slot, &info.level)) return false;
        if (!readByte(d, UNIT_AURA_APPLICATIONS, slot, &info.applications)) return false;
        if (info.spellId) ++active;
        out[slot] = info;
    }
    *activeCount = active; return true;
}

static bool sameInfo(const AuraInfo& a, const AuraInfo& b) {
    return a.spellId == b.spellId && a.flags == b.flags && a.level == b.level && a.applications == b.applications;
}

static void setField(Lua50::State L, const char* key, double value) {
    Lua50::PushString(L, key); Lua50::PushNumber(L, value); Lua50::SetTable(L, -3);
}
static void setField(Lua50::State L, const char* key, const char* value) {
    Lua50::PushString(L, key); Lua50::PushString(L, value); Lua50::SetTable(L, -3);
}
static void pushInfo(Lua50::State L, const AuraInfo& info) {
    Lua50::NewTable(L);
    setField(L, "unit", "player"); setField(L, "spellID", (double)info.spellId);
    setField(L, "slot", (double)info.slot); setField(L, "flags", (double)info.flags);
    setField(L, "level", (double)info.level); setField(L, "applications", (double)info.applications);
    setField(L, "stack", (double)info.applications); setField(L, "casterGUID", (double)info.casterGuid);
    setField(L, "duration", (double)info.durationMs / 1000.0); setField(L, "expiration", (double)info.expirationMs / 1000.0);
}

static void invokeCallback(Lua50::State L, const char* eventName, const AuraInfo& info) {
    if (!L || !eventName) return;
    int top = Lua50::GetTop(L); Lua50::GetGlobal(L, "TaiYangShenDian_AuraCallback");
    if (Lua50::Type(L, -1) != LUA_TFUNCTION) { Lua50::SetTop(L, top); return; }
    Lua50::PushString(L, eventName); Lua50::PushString(L, "player"); pushInfo(L, info);
    Lua50::PCall(L, 3, 0, 0); Lua50::SetTop(L, top);
}

static void sync(Lua50::State L, bool emit) {
    AuraInfo next[UNIT_AURA_COUNT] = {}; unsigned nextCount = 0;
    if (!readSnapshot(next, &nextCount)) { copyText(g_status, sizeof(g_status), "PLAYER_AURA_UNAVAILABLE"); return; }
    if (!g_ready) {
        for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) {
            if (emit && next[slot].spellId) invokeCallback(L, "AURA_ADDED", next[slot]);
            g_cache[slot] = next[slot];
        }
        g_ready = true; g_count = nextCount; copyText(g_status, sizeof(g_status), "READY_EVENT_DRIVEN"); return;
    }
    for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) {
        const AuraInfo& oldInfo = g_cache[slot]; const AuraInfo& newInfo = next[slot];
        if (!oldInfo.spellId && newInfo.spellId) { if (emit) invokeCallback(L, "AURA_ADDED", newInfo); }
        else if (oldInfo.spellId && !newInfo.spellId) { if (emit) invokeCallback(L, "AURA_REMOVED", oldInfo); }
        else if (oldInfo.spellId && newInfo.spellId) {
            if (oldInfo.applications != newInfo.applications) { if (emit) invokeCallback(L, "AURA_STACK_CHANGED", newInfo); }
            else if (!sameInfo(oldInfo, newInfo)) { if (emit) invokeCallback(L, "AURA_UPDATED", newInfo); }
        }
        g_cache[slot] = newInfo;
    }
    g_count = nextCount; copyText(g_status, sizeof(g_status), "READY_EVENT_DRIVEN");
}

static bool validPlayerUnit(Lua50::State L, int index) {
    if (Lua50::GetTop(L) < index || !Lua50::IsString(L, index)) return true;
    const char* token = Lua50::ToString(L, index);
    if (!token) return false;
    return token[0] == 'p' && token[1] == 'l' && token[2] == 'a' && token[3] == 'y' && token[4] == 'e' && token[5] == 'r' && token[6] == 0;
}

static int doStatus(Lua50::State L) { Lua50::PushBool(L, true); Lua50::PushString(L, g_status); Lua50::PushNumber(L, (double)g_count); Lua50::PushBool(L, g_ready); return 4; }

static int doSetCallback(Lua50::State L) {
    int callbackType = Lua50::GetTop(L) >= 2 ? Lua50::Type(L, 2) : 0;
    if (callbackType != LUA_TFUNCTION && callbackType != 0) { Lua50::PushBool(L, false); Lua50::PushString(L, "CALLBACK_MUST_BE_FUNCTION"); return 2; }
    if (callbackType == 0) Lua50::PushNil(L); else Lua50::PushValue(L, 2);
    Lua50::PushString(L, "TaiYangShenDian_AuraCallback"); Lua50::Insert(L, -2); Lua50::SetTable(L, LUA_GLOBALSINDEX);
    if (callbackType == LUA_TFUNCTION) { clearCache(); sync(L, true); }
    Lua50::PushBool(L, true); Lua50::PushString(L, "OK"); return 2;
}

static int doRefresh(Lua50::State L) { if (!validPlayerUnit(L, 2)) { Lua50::PushBool(L, false); Lua50::PushString(L, "PLAYER_ONLY"); return 2; } sync(L, true); Lua50::PushBool(L, g_ready); Lua50::PushString(L, g_status); Lua50::PushNumber(L, (double)g_count); return 3; }

static int doGet(Lua50::State L) {
    if (!validPlayerUnit(L, 2) || Lua50::GetTop(L) < 3 || !Lua50::IsNumber(L, 3)) { Lua50::PushNil(L); Lua50::PushString(L, "BAD_ARGUMENT"); return 2; }
    sync(L, false); long slot = (long)Lua50::ToNumber(L, 3);
    if (slot < 0 || slot >= (long)UNIT_AURA_COUNT || !g_cache[slot].spellId) { Lua50::PushNil(L); Lua50::PushString(L, "AURA_NOT_FOUND"); return 2; }
    pushInfo(L, g_cache[slot]); return 1;
}

static int doSnapshot(Lua50::State L) {
    if (!validPlayerUnit(L, 2)) { Lua50::PushNil(L); Lua50::PushString(L, "PLAYER_ONLY"); return 2; }
    sync(L, false); Lua50::NewTable(L); int arrayIndex = 1;
    for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) if (g_cache[slot].spellId) { Lua50::PushNumber(L, (double)arrayIndex++); pushInfo(L, g_cache[slot]); Lua50::SetTable(L, -3); }
    return 1;
}

void reset() { clearCache(); copyText(g_status, sizeof(g_status), "RESET"); }
void onEvent(Lua50::State L, const char* eventName) {
    if (!eventName) return;
    if (eventName[0] == 'P' && eventName[1] == 'L') { clearCache(); copyText(g_status, sizeof(g_status), "WORLD_RESET"); return; }
    if (eventName[0] == 'U' && eventName[1] == 'N') sync(L, true);
}
int dispatch(Lua50::State L, const char* command) {
    if (!command || command[0] != 'A' || command[1] != 'u' || command[2] != 'r' || command[3] != 'a' || command[4] != '.') return -1;
    if (command[5] == 'S' && command[6] == 't' && command[7] == 'a' && command[8] == 't' && command[9] == 'u' && command[10] == 's' && command[11] == 0) return doStatus(L);
    if (command[5] == 'S' && command[6] == 'e' && command[7] == 't' && command[8] == 'C' && command[9] == 'a' && command[10] == 'l' && command[11] == 'l' && command[12] == 'b' && command[13] == 'a' && command[14] == 'c' && command[15] == 'k' && command[16] == 0) return doSetCallback(L);
    if (command[5] == 'R' && command[6] == 'e' && command[7] == 'f' && command[8] == 'r' && command[9] == 'e' && command[10] == 's' && command[11] == 'h' && command[12] == 0) return doRefresh(L);
    if (command[5] == 'G' && command[6] == 'e' && command[7] == 't' && command[8] == 0) return doGet(L);
    if (command[5] == 'S' && command[6] == 'n' && command[7] == 'a' && command[8] == 'p' && command[9] == 's' && command[10] == 'h' && command[11] == 'o' && command[12] == 't' && command[13] == 0) return doSnapshot(L);
    if (command[5] == 'R' && command[6] == 'e' && command[7] == 's' && command[8] == 'e' && command[9] == 't' && command[10] == 0) { reset(); Lua50::PushBool(L, true); return 1; }
    return -1;
}
const char* status() { return g_status; }
unsigned count() { return g_count; }

}
