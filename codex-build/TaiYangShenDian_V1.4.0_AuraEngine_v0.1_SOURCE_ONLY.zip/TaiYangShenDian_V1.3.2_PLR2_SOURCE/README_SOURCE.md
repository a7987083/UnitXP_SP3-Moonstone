# TaiYangShenDian V1.3.2-PLR2 source

This source package is the buildable Native runtime only. The old `Interface\\AddOns\\TaiYangShenDian` companion addon is intentionally not included because the process-lifetime runtime owns lifecycle inside the DLL.

Build from `build/build.sh`. The build remains x86 / WoW 1.12.1, `/nodefaultlib`, Windows subsystem 5.01, deterministic timestamp 0.

PLR2 delta from PLR1 is intentionally narrow and contained in `src/dllmain.cpp`:

- Removed the PLAYER lifecycle owner whitelist / compatibility branch (`VanillaHelpers.dll`, `Reliquary.dll`).
- Removed rejection of unrecognized PLAYER entry owners (`HOOK_CONFLICT_UNKNOWN_PLAYER_OWNER`).
- Removed owner-dependent selection of another module's detour destination.
- The runtime now calls MinHook directly on the fixed `WoW112::PLAYER_LOAD_SCRIPT_FUNCTIONS` entry, stores MinHook's trampoline in `g_playerNext`, and enables that hook.
- `PLAYER_LOAD_SCRIPT_FUNCTIONS` inspection remains observe-only for diagnostics; it no longer decides whether or where the PLAYER hook is installed.
- Added `src/aura_engine.cpp`: player `UNIT_AURA` event reader, 48-slot native cache, diff events and Lua `Aura.*` API. The existing API version remains 15.
- API version remains 15. All DBC, Visual, MoonMarker, Profiler, DreamAvatar, DreamWeapon and addon-facing API behavior is otherwise unchanged.
