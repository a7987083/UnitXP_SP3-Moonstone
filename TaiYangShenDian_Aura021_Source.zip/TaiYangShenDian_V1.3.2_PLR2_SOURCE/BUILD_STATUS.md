# V1.4.1-AURA0.2.1 build status

Implementation is complete for automatic Nampower/Standalone dual mode, corrected WoW 5875 Aura layout, custom spell-ID lookup, automatic target `UNIT_AURA_GUID` callbacks, and the DreamWeapon-style companion diagnostic addon.

Final x86 DLL build and PE verification are pending. See `BUILD_STATUS_V021.md` for the detailed checklist.
