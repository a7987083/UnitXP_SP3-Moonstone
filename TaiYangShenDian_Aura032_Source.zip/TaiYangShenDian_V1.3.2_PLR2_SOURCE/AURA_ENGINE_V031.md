# TaiYangShenDian AuraEngine v0.3.1

Paired DLL: `1.4.3-AURA0.3.1`.

## FPS hotfix

Version 0.3.0 intentionally had both DLL relay and direct Lua Nampower event paths. A target Aura removal could enter both paths with different stack values, bypass the short deduplication key, and cause excessive UI/event work on affected clients.

Version 0.3.1 uses exactly one path in Nampower mode:

- TaiYangAura directly receives the eight Nampower Buff/Debuff events.
- TaiYangAura clears the DLL Aura callback.
- The DLL skips Nampower Aura and `UNIT_AURA_GUID` snapshot work while no callback is installed.
- Lua rejects repeated removal of an already-absent Aura, deduplicates matching callbacks for 0.5 seconds, and blocks more than 20 Aura events per second.

Standalone mode still uses the DLL callback and native Aura hooks. API version remains 15.
