# V1.4.1-AURA0.2.1 build status

Implementation is complete for automatic Nampower/Standalone dual mode, corrected WoW 5875 Aura layout, custom spell-ID lookup, automatic target `UNIT_AURA_GUID` callbacks, and the DreamWeapon-style companion diagnostic addon.

Final x86 DLL build and PE verification passed in GitHub Actions run `32813617414`. See `BUILD_STATUS_V021.md` for the detailed checklist and SHA-256.
