# TaiYangShenDian AuraEngine v0.3.0

Paired DLL version: `1.4.2-AURA0.3.0`.

## Target event fix

Nampower `BUFF_*_OTHER` and `DEBUFF_*_OTHER` events carry the affected unit GUID in `arg1`. Version 0.3.0 resolves the current target with Nampower's `GetUnitGUID("target")` and compares those GUIDs before forwarding the event to the registered Lua callback. The older fixed object-offset GUID lookup remains only as a fallback.

This fixes the failure mode where `Aura.Find("target", spellID)` succeeded only after a button click while automatic poison add/stack/remove callbacks were dropped.

## Dual mode

- Nampower present: consume its eight Aura events; do not install duplicate Aura hooks.
- Nampower absent: use the standalone MinHook add/remove/stack path.
- The companion `TaiYangAura` 0.3.0 addon also registers the Nampower events directly as a redundant event path and deduplicates identical callbacks.

Nampower `arg4` is already the one-based current stack count. Raw client `auraApplications` storage remains zero-based and snapshot output converts it with `+1`.
