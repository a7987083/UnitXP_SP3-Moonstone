# V1.4.3-AURA0.3.1 build status

- Target: 32-bit Windows PE DLL for WoW 1.12.1 build 5875.
- API version: 15.
- Build ID: `20260825-v143-aura031-single-channel-fps`.
- Nampower mode: direct Lua single channel; DLL callback cleared.
- Standalone mode: DLL native Hook callback retained.
- Companion addon: TaiYangAura 0.3.1 with event flood protection.
