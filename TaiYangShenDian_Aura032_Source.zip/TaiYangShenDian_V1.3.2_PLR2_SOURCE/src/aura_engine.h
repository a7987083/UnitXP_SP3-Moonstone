#pragma once

#include "lua50.h"

namespace TysAura {
    bool initialize(Lua50::State L);
    bool wantsNampowerEvents();
    void setNampowerEventsRegistered(bool registered);
    void reset();
    void onEvent(Lua50::State L, const char* eventName, const char* unitToken = 0);
    int dispatch(Lua50::State L, const char* command);
    const char* mode();
    const char* status();
    unsigned count();
}
