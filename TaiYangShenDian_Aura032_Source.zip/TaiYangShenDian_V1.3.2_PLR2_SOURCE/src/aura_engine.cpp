#include <windows.h>
#include "../third_party/minhook/include/MinHook.h"
#include "aura_engine.h"

namespace TysAura {

constexpr unsigned long UNIT_FIELDS_POINTER = 0x110UL;
constexpr unsigned long UNIT_GUID_OFFSET = 0x30UL;
constexpr unsigned long UNIT_AURA_FIRST = 0x29UL;
constexpr unsigned long UNIT_AURA_COUNT = 48UL;
constexpr unsigned long UNIT_AURA_FLAGS = 0x59UL;
constexpr unsigned long UNIT_AURA_LEVELS = 0x5FUL;
constexpr unsigned long UNIT_AURA_APPLICATIONS = 0x6BUL;
constexpr unsigned long RESOLVE_UNIT_TOKEN = 0x00515940UL;
constexpr unsigned long AURA_REMOVED_TARGET = 0x00612320UL;
constexpr unsigned long AURA_ADDED_TARGET = 0x006123F0UL;
constexpr unsigned long AURA_STACK_TARGET = 0x00612450UL;
constexpr unsigned long SIGNAL_EVENT_PARAM = 0x00703F50UL;
constexpr int UNIT_AURA_EVENT_ID = 41;
constexpr int LUA_GLOBALSINDEX = -10001;
constexpr int LUA_TFUNCTION = 6;
constexpr int AURA_UNIT_PLAYER = 0;
constexpr int AURA_UNIT_TARGET = 1;
constexpr int AURA_UNIT_COUNT = 2;

enum RuntimeMode {
    MODE_NOT_INITIALIZED = 0,
    MODE_NAMPOWER_EVENTS = 1,
    MODE_STANDALONE_NATIVE = 2,
    MODE_PASSIVE_UNIT_AURA = 3
};

using ResolveUnitFn = void* (__fastcall *)(const char*);
using AuraAddedFn = void (__fastcall *)(void*, void*, unsigned long, unsigned long);
using AuraRemovedFn = void (__fastcall *)(void*, void*, unsigned long, unsigned long);
using AuraStackFn = void (__fastcall *)(void*, void*, int, unsigned char);

struct AuraInfo {
    unsigned long spellId;
    unsigned long slot;
    unsigned char flags;
    unsigned char level;
    unsigned char applications;
    unsigned char reserved;
    unsigned long long casterGuid;
    unsigned long durationMs;
    unsigned long expirationMs;
};

static AuraInfo g_cache[AURA_UNIT_COUNT][UNIT_AURA_COUNT] = {};
static bool g_ready[AURA_UNIT_COUNT] = {};
static char g_status[AURA_UNIT_COUNT][96] = {"NOT_INITIALIZED", "NOT_INITIALIZED"};
static unsigned g_count[AURA_UNIT_COUNT] = {};
static RuntimeMode g_mode = MODE_NOT_INITIALIZED;
static Lua50::State g_luaState = 0;
static bool g_nampowerDetected = false;
static bool g_nampowerEventsRegistered = false;
static bool g_callbackInstalled = false;
static bool g_nativeHooksCreated = false;
static bool g_nativeHooksEnabled = false;
static void* g_trackedPlayerObject = 0;
static void* g_trackedTargetObject = 0;
static char g_modeStatus[128] = "NOT_INITIALIZED";
static AuraAddedFn g_auraAddedNext = 0;
static AuraRemovedFn g_auraRemovedNext = 0;
static AuraStackFn g_auraStackNext = 0;

static bool textEquals(const char* left, const char* right) {
    if (!left || !right) return false;
    unsigned long i = 0;
    while (left[i] && right[i] && left[i] == right[i]) ++i;
    return left[i] == 0 && right[i] == 0;
}

static bool textStarts(const char* text, const char* prefix) {
    if (!text || !prefix) return false;
    while (*prefix) { if (*text++ != *prefix++) return false; }
    return true;
}

static const char* unitName(int unit) { return unit == AURA_UNIT_TARGET ? "target" : "player"; }

static int unitIndex(const char* token) {
    if (!token) return -1;
    if (textEquals(token, "player")) return AURA_UNIT_PLAYER;
    if (textEquals(token, "target")) return AURA_UNIT_TARGET;
    return -1;
}

static int luaUnitIndex(Lua50::State L, int index) {
    if (Lua50::GetTop(L) < index) return AURA_UNIT_PLAYER;
    if (!Lua50::IsString(L, index)) return -1;
    return unitIndex(Lua50::ToString(L, index));
}

static bool readable(const void* address, unsigned long size) {
    if (!address || !size) return false;
    MEMORY_BASIC_INFORMATION m = {};
    if (VirtualQuery(address, &m, sizeof(m)) != sizeof(m)) return false;
    if (m.State != MEM_COMMIT) return false;
    DWORD protection = m.Protect & 0xFF;
    if (protection == PAGE_NOACCESS || protection == PAGE_EXECUTE) return false;
    unsigned long begin = (unsigned long)address;
    unsigned long end = (unsigned long)m.BaseAddress + (unsigned long)m.RegionSize;
    return end >= begin && size <= end - begin;
}

static void copyText(char* out, unsigned long capacity, const char* text) {
    if (!out || !capacity) return;
    unsigned long i = 0;
    if (text) while (text[i] && i + 1 < capacity) { out[i] = text[i]; ++i; }
    out[i] = 0;
}

static void clearInfo(AuraInfo* info, unsigned long slot) {
    if (!info) return;
    info->spellId = 0; info->slot = slot; info->flags = 0; info->level = 0;
    info->applications = 0; info->reserved = 0; info->casterGuid = 0;
    info->durationMs = 0; info->expirationMs = 0;
}

static void clearUnitCache(int unit) {
    if (unit < 0 || unit >= AURA_UNIT_COUNT) return;
    for (unsigned long i = 0; i < UNIT_AURA_COUNT; ++i) clearInfo(&g_cache[unit][i], i);
    g_ready[unit] = false; g_count[unit] = 0;
}

static void clearAllCaches() { clearUnitCache(AURA_UNIT_PLAYER); clearUnitCache(AURA_UNIT_TARGET); }

static void* unitObject(int unit) {
    if (!readable((void*)RESOLVE_UNIT_TOKEN, 1)) return 0;
    return ((ResolveUnitFn)RESOLVE_UNIT_TOKEN)(unitName(unit));
}

static unsigned long long unitGuid(void* object) {
    if (!object || !readable((unsigned char*)object + UNIT_GUID_OFFSET, 8)) return 0;
    return *(unsigned long long*)((unsigned char*)object + UNIT_GUID_OFFSET);
}

static bool unitFields(void* object, unsigned char** out) {
    if (!object || !out || !readable((unsigned char*)object + UNIT_FIELDS_POINTER, 4)) return false;
    unsigned char* d = *(unsigned char**)((unsigned char*)object + UNIT_FIELDS_POINTER);
    const unsigned long bytesRequired = (UNIT_AURA_APPLICATIONS * 4UL) + UNIT_AURA_COUNT;
    if (!d || !readable(d, bytesRequired)) return false;
    *out = d; return true;
}

static bool readDword(unsigned char* d, unsigned long field, unsigned long* out) {
    if (!d || !out || !readable(d + field * 4UL, 4)) return false;
    *out = *(unsigned long*)(d + field * 4UL); return true;
}

static bool readByteAt(unsigned char* address, unsigned char* out) {
    if (!address || !out || !readable(address, 1)) return false;
    *out = *address; return true;
}

static bool readSnapshot(int unit, AuraInfo* out, unsigned* activeCount) {
    if (unit < 0 || unit >= AURA_UNIT_COUNT || !out || !activeCount) return false;
    unsigned char* d = 0; void* object = unitObject(unit);
    if (!object || !unitFields(object, &d)) return false;
    unsigned active = 0;
    for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) {
        AuraInfo info = {}; clearInfo(&info, slot);
        unsigned char packedFlags = 0, rawApplications = 0;
        if (!readDword(d, UNIT_AURA_FIRST + slot, &info.spellId)) return false;
        if (!readByteAt(d + UNIT_AURA_FLAGS * 4UL + slot / 2UL, &packedFlags)) return false;
        info.flags = (unsigned char)((packedFlags >> ((slot & 1UL) * 4UL)) & 0x0FUL);
        if (!readByteAt(d + UNIT_AURA_LEVELS * 4UL + slot, &info.level)) return false;
        if (!readByteAt(d + UNIT_AURA_APPLICATIONS * 4UL + slot, &rawApplications)) return false;
        info.applications = info.spellId ? (unsigned char)(rawApplications + 1U) : 0;
        if (info.spellId) ++active;
        out[slot] = info;
    }
    *activeCount = active; return true;
}

static bool readAuraSlot(void* object, unsigned long slot, AuraInfo* out) {
    if (!object || !out || slot >= UNIT_AURA_COUNT) return false;
    unsigned char* d = 0;
    if (!unitFields(object, &d)) return false;
    AuraInfo info = {}; clearInfo(&info, slot);
    unsigned char packedFlags = 0, rawApplications = 0;
    if (!readDword(d, UNIT_AURA_FIRST + slot, &info.spellId)) return false;
    if (!readByteAt(d + UNIT_AURA_FLAGS * 4UL + slot / 2UL, &packedFlags)) return false;
    info.flags = (unsigned char)((packedFlags >> ((slot & 1UL) * 4UL)) & 0x0FUL);
    if (!readByteAt(d + UNIT_AURA_LEVELS * 4UL + slot, &info.level)) return false;
    if (!readByteAt(d + UNIT_AURA_APPLICATIONS * 4UL + slot, &rawApplications)) return false;
    info.applications = info.spellId ? (unsigned char)(rawApplications + 1U) : 0;
    *out = info;
    return true;
}

static bool sameInfo(const AuraInfo& a, const AuraInfo& b) {
    return a.spellId == b.spellId && a.flags == b.flags && a.level == b.level && a.applications == b.applications;
}

static void setField(Lua50::State L, const char* key, double value) {
    Lua50::PushString(L, key); Lua50::PushNumber(L, value); Lua50::SetTable(L, -3);
}
static void setField(Lua50::State L, const char* key, const char* value) {
    Lua50::PushString(L, key); Lua50::PushString(L, value); Lua50::SetTable(L, -3);
}
static void setBoolField(Lua50::State L, const char* key, bool value) {
    Lua50::PushString(L, key); Lua50::PushBool(L, value); Lua50::SetTable(L, -3);
}

const char* mode();

static void pushInfo(Lua50::State L, int unit, const AuraInfo& info) {
    const bool isDebuff = info.slot >= 32UL;
    Lua50::NewTable(L);
    setField(L, "unit", unitName(unit)); setField(L, "spellID", (double)info.spellId);
    setField(L, "slot", (double)info.slot); setField(L, "flags", (double)info.flags);
    setField(L, "level", (double)info.level); setField(L, "applications", (double)info.applications);
    setField(L, "stack", (double)info.applications); setField(L, "casterGUID", (double)info.casterGuid);
    setField(L, "duration", (double)info.durationMs / 1000.0); setField(L, "expiration", (double)info.expirationMs / 1000.0);
    setField(L, "auraType", isDebuff ? "DEBUFF" : "BUFF"); setBoolField(L, "isDebuff", isDebuff);
    setField(L, "sourceMode", mode());
}

static void invokeCallback(Lua50::State L, const char* eventName, int unit, const AuraInfo& info) {
    if (!L || !eventName) return;
    int top = Lua50::GetTop(L); Lua50::GetGlobal(L, "TaiYangShenDian_AuraCallback");
    if (Lua50::Type(L, -1) != LUA_TFUNCTION) { Lua50::SetTop(L, top); return; }
    Lua50::PushString(L, eventName); Lua50::PushString(L, unitName(unit)); pushInfo(L, unit, info);
    Lua50::PCall(L, 3, 0, 0); Lua50::SetTop(L, top);
}

static bool syncUnit(Lua50::State L, int unit, bool emit) {
    if (unit < 0 || unit >= AURA_UNIT_COUNT) return false;
    AuraInfo next[UNIT_AURA_COUNT] = {}; unsigned nextCount = 0;
    if (!readSnapshot(unit, next, &nextCount)) {
        if (unit == AURA_UNIT_TARGET) clearUnitCache(unit);
        copyText(g_status[unit], sizeof(g_status[unit]), unit == AURA_UNIT_TARGET ? "TARGET_AURA_UNAVAILABLE" : "PLAYER_AURA_UNAVAILABLE");
        return false;
    }
    if (!g_ready[unit]) {
        for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) {
            if (emit && next[slot].spellId) invokeCallback(L, "AURA_ADDED", unit, next[slot]);
            g_cache[unit][slot] = next[slot];
        }
        g_ready[unit] = true; g_count[unit] = nextCount; copyText(g_status[unit], sizeof(g_status[unit]), "READY"); return true;
    }
    for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) {
        const AuraInfo& oldInfo = g_cache[unit][slot]; const AuraInfo& newInfo = next[slot];
        if (!oldInfo.spellId && newInfo.spellId) { if (emit) invokeCallback(L, "AURA_ADDED", unit, newInfo); }
        else if (oldInfo.spellId && !newInfo.spellId) { if (emit) invokeCallback(L, "AURA_REMOVED", unit, oldInfo); }
        else if (oldInfo.spellId && newInfo.spellId) {
            if (oldInfo.applications != newInfo.applications) { if (emit) invokeCallback(L, "AURA_STACK_CHANGED", unit, newInfo); }
            else if (!sameInfo(oldInfo, newInfo)) { if (emit) invokeCallback(L, "AURA_UPDATED", unit, newInfo); }
        }
        g_cache[unit][slot] = newInfo;
    }
    g_count[unit] = nextCount; copyText(g_status[unit], sizeof(g_status[unit]), "READY"); return true;
}

static void refreshTrackedObjects() {
    g_trackedPlayerObject = unitObject(AURA_UNIT_PLAYER);
    g_trackedTargetObject = unitObject(AURA_UNIT_TARGET);
}

static int trackedUnitFromObject(void* object) {
    if (!object) return -1;
    if (object == g_trackedPlayerObject) return AURA_UNIT_PLAYER;
    if (object == g_trackedTargetObject) return AURA_UNIT_TARGET;
    return -1;
}

static void signalNativeAuraEvent(int unit, unsigned long state, const AuraInfo& info) {
    if (unit < 0 || unit >= AURA_UNIT_COUNT || !readable((void*)SIGNAL_EVENT_PARAM, 1)) return;
    static char format[] = "%s%s%d%d%d%d%d";
    ((int (__cdecl *)(int, char*, char*, char*, unsigned long, unsigned long, unsigned long, unsigned long, unsigned long))SIGNAL_EVENT_PARAM)(
        UNIT_AURA_EVENT_ID, format, "TYS_AURA", (char*)unitName(unit), state, info.spellId,
        (unsigned long)info.applications, info.slot, (unsigned long)info.level);
}

static void __fastcall auraAddedHook(void* unit, void* edx, unsigned long slot, unsigned long spellId) {
    if (g_auraAddedNext) g_auraAddedNext(unit, edx, slot, spellId);
    const int trackedUnit = trackedUnitFromObject(unit);
    AuraInfo info = {}; clearInfo(&info, slot); info.spellId = spellId;
    if (trackedUnit >= 0 && readAuraSlot(unit, slot, &info)) signalNativeAuraEvent(trackedUnit, 0, info);
}
static void __fastcall auraRemovedHook(void* unit, void* edx, unsigned long slot, unsigned long spellId) {
    if (g_auraRemovedNext) g_auraRemovedNext(unit, edx, slot, spellId);
    const int trackedUnit = trackedUnitFromObject(unit);
    AuraInfo info = {}; clearInfo(&info, slot); info.spellId = spellId;
    if (trackedUnit >= 0) signalNativeAuraEvent(trackedUnit, 1, info);
}
static void __fastcall auraStackHook(void* unit, void* edx, int slot, unsigned char stackCount) {
    if (g_auraStackNext) g_auraStackNext(unit, edx, slot, stackCount);
    const int trackedUnit = trackedUnitFromObject(unit);
    AuraInfo info = {}; clearInfo(&info, (unsigned long)slot);
    if (trackedUnit >= 0 && slot >= 0 && readAuraSlot(unit, (unsigned long)slot, &info)) signalNativeAuraEvent(trackedUnit, 2, info);
}

static bool prologueMatches(unsigned long address, const unsigned char* expected, unsigned long count) {
    if (!expected || !readable((void*)address, count)) return false;
    const unsigned char* p = (const unsigned char*)address;
    for (unsigned long i = 0; i < count; ++i) if (p[i] != expected[i]) return false;
    return true;
}

static void removeNativeHooks() {
    if (g_nativeHooksCreated) {
        MH_DisableHook((LPVOID)AURA_ADDED_TARGET); MH_DisableHook((LPVOID)AURA_REMOVED_TARGET); MH_DisableHook((LPVOID)AURA_STACK_TARGET);
        MH_RemoveHook((LPVOID)AURA_ADDED_TARGET); MH_RemoveHook((LPVOID)AURA_REMOVED_TARGET); MH_RemoveHook((LPVOID)AURA_STACK_TARGET);
    }
    g_nativeHooksCreated = false; g_nativeHooksEnabled = false;
    g_auraAddedNext = 0; g_auraRemovedNext = 0; g_auraStackNext = 0;
}

static bool installNativeHooks() {
    const unsigned char removedPrologue[5] = {0x55, 0x8B, 0xEC, 0x51, 0x53};
    const unsigned char addedPrologue[5] = {0x55, 0x8B, 0xEC, 0x53, 0x8B};
    const unsigned char stackPrologue[5] = {0x55, 0x8B, 0xEC, 0x8B, 0x81};
    if (!prologueMatches(AURA_REMOVED_TARGET, removedPrologue, 5) || !prologueMatches(AURA_ADDED_TARGET, addedPrologue, 5) || !prologueMatches(AURA_STACK_TARGET, stackPrologue, 5)) {
        copyText(g_modeStatus, sizeof(g_modeStatus), "AURA_ENTRY_ALREADY_MODIFIED_PASSIVE_FALLBACK"); return false;
    }
    MH_STATUS init = MH_Initialize();
    if (init != MH_OK && init != MH_ERROR_ALREADY_INITIALIZED) { copyText(g_modeStatus, sizeof(g_modeStatus), "MINHOOK_INIT_FAILED_PASSIVE_FALLBACK"); return false; }
    if (MH_CreateHook((LPVOID)AURA_ADDED_TARGET, (LPVOID)&auraAddedHook, (LPVOID*)&g_auraAddedNext) != MH_OK ||
        MH_CreateHook((LPVOID)AURA_REMOVED_TARGET, (LPVOID)&auraRemovedHook, (LPVOID*)&g_auraRemovedNext) != MH_OK ||
        MH_CreateHook((LPVOID)AURA_STACK_TARGET, (LPVOID)&auraStackHook, (LPVOID*)&g_auraStackNext) != MH_OK) {
        g_nativeHooksCreated = true; removeNativeHooks(); copyText(g_modeStatus, sizeof(g_modeStatus), "AURA_HOOK_CREATE_FAILED_PASSIVE_FALLBACK"); return false;
    }
    g_nativeHooksCreated = true;
    if (MH_EnableHook((LPVOID)AURA_ADDED_TARGET) != MH_OK || MH_EnableHook((LPVOID)AURA_REMOVED_TARGET) != MH_OK || MH_EnableHook((LPVOID)AURA_STACK_TARGET) != MH_OK) {
        removeNativeHooks(); copyText(g_modeStatus, sizeof(g_modeStatus), "AURA_HOOK_ENABLE_FAILED_PASSIVE_FALLBACK"); return false;
    }
    g_nativeHooksEnabled = true; copyText(g_modeStatus, sizeof(g_modeStatus), "STANDALONE_NATIVE_HOOK_READY"); return true;
}

static bool getGlobalNumber(Lua50::State L, const char* name, unsigned long* out) {
    if (!L || !name || !out) return false;
    const int top = Lua50::GetTop(L); Lua50::GetGlobal(L, name);
    if (!Lua50::IsNumber(L, -1)) { Lua50::SetTop(L, top); return false; }
    *out = (unsigned long)Lua50::ToNumber(L, -1); Lua50::SetTop(L, top); return true;
}

static unsigned long long parseGuid(const char* text) {
    if (!text) return 0;
    if (text[0] == '0' && (text[1] == 'x' || text[1] == 'X')) text += 2;
    unsigned long long value = 0;
    for (unsigned i = 0; text[i]; ++i) {
        unsigned digit = 16;
        if (text[i] >= '0' && text[i] <= '9') digit = (unsigned)(text[i] - '0');
        else if (text[i] >= 'a' && text[i] <= 'f') digit = (unsigned)(text[i] - 'a' + 10);
        else if (text[i] >= 'A' && text[i] <= 'F') digit = (unsigned)(text[i] - 'A' + 10);
        else break;
        value = (value << 4) | digit;
    }
    return value;
}

static unsigned long long luaUnitGuid(Lua50::State L, const char* unitToken) {
    if (!L || !unitToken) return 0;
    const int top = Lua50::GetTop(L);
    Lua50::GetGlobal(L, "GetUnitGUID");
    if (Lua50::Type(L, -1) != LUA_TFUNCTION) { Lua50::SetTop(L, top); return 0; }
    Lua50::PushString(L, unitToken);
    if (Lua50::PCall(L, 1, 1, 0) != 0 || !Lua50::IsString(L, -1)) { Lua50::SetTop(L, top); return 0; }
    const unsigned long long guid = parseGuid(Lua50::ToString(L, -1));
    Lua50::SetTop(L, top);
    return guid;
}

static int nampowerEventUnit(Lua50::State L, const char* eventName) {
    if (!eventName) return -1;
    if (textEquals(eventName, "BUFF_ADDED_SELF") || textEquals(eventName, "BUFF_REMOVED_SELF") || textEquals(eventName, "DEBUFF_ADDED_SELF") || textEquals(eventName, "DEBUFF_REMOVED_SELF")) return AURA_UNIT_PLAYER;
    const int top = Lua50::GetTop(L); Lua50::GetGlobal(L, "arg1");
    const char* guidText = Lua50::IsString(L, -1) ? Lua50::ToString(L, -1) : 0;
    const unsigned long long eventGuid = parseGuid(guidText); Lua50::SetTop(L, top);
    if (!eventGuid) return -1;
    unsigned long long currentTargetGuid = luaUnitGuid(L, "target");
    if (!currentTargetGuid) currentTargetGuid = unitGuid(unitObject(AURA_UNIT_TARGET));
    return eventGuid == currentTargetGuid ? AURA_UNIT_TARGET : -1;
}

static void handleNampowerEvent(Lua50::State L, const char* eventName) {
    if (!L || !eventName || g_mode != MODE_NAMPOWER_EVENTS || !g_nampowerEventsRegistered || !g_callbackInstalled) return;
    const int unit = nampowerEventUnit(L, eventName);
    unsigned long slot = 0, spellId = 0, stack = 0, level = 0, state = 0;
    const bool ok = unit >= 0 && getGlobalNumber(L, "arg6", &slot) && getGlobalNumber(L, "arg3", &spellId) &&
        getGlobalNumber(L, "arg4", &stack) && getGlobalNumber(L, "arg5", &level) && getGlobalNumber(L, "arg7", &state) && slot < UNIT_AURA_COUNT;
    if (!ok) return;
    if (!g_ready[unit]) syncUnit(L, unit, false);
    AuraInfo oldInfo = g_cache[unit][slot]; AuraInfo info = {}; clearInfo(&info, slot);
    info.spellId = spellId; info.level = (unsigned char)level; info.applications = (unsigned char)stack;
    if (state == 1UL) {
        if (!oldInfo.spellId) oldInfo = info;
        clearInfo(&g_cache[unit][slot], slot); if (g_count[unit]) --g_count[unit];
        invokeCallback(L, "AURA_REMOVED", unit, oldInfo);
    } else {
        AuraInfo snapshot[UNIT_AURA_COUNT] = {}; unsigned active = 0;
        if (readSnapshot(unit, snapshot, &active)) { info = snapshot[slot]; g_count[unit] = active; }
        if (state == 0UL && !g_cache[unit][slot].spellId && !active) ++g_count[unit];
        g_cache[unit][slot] = info;
        invokeCallback(L, state == 2UL ? "AURA_STACK_CHANGED" : "AURA_ADDED", unit, info);
    }
    g_ready[unit] = true; copyText(g_status[unit], sizeof(g_status[unit]), "READY_NAMPOWER_EVENTS");
}

static int doStatus(Lua50::State L) {
    const int unit = luaUnitIndex(L, 2);
    if (unit < 0) { Lua50::PushBool(L, false); Lua50::PushString(L, "UNIT_NOT_SUPPORTED"); Lua50::PushNumber(L, 0); Lua50::PushBool(L, false); return 4; }
    Lua50::PushBool(L, true); Lua50::PushString(L, g_status[unit]); Lua50::PushNumber(L, (double)g_count[unit]); Lua50::PushBool(L, g_ready[unit]); return 4;
}

static int doMode(Lua50::State L) {
    Lua50::PushString(L, mode()); Lua50::PushBool(L, g_nampowerDetected); Lua50::PushBool(L, g_nampowerEventsRegistered);
    Lua50::PushBool(L, g_nativeHooksEnabled); Lua50::PushString(L, g_modeStatus); return 5;
}

static int doSetCallback(Lua50::State L) {
    int callbackType = Lua50::GetTop(L) >= 2 ? Lua50::Type(L, 2) : 0;
    if (callbackType != LUA_TFUNCTION && callbackType != 0) { Lua50::PushBool(L, false); Lua50::PushString(L, "CALLBACK_MUST_BE_FUNCTION"); return 2; }
    if (callbackType == 0) Lua50::PushNil(L); else Lua50::PushValue(L, 2);
    Lua50::PushString(L, "TaiYangShenDian_AuraCallback"); Lua50::Insert(L, -2); Lua50::SetTable(L, LUA_GLOBALSINDEX);
    g_callbackInstalled = callbackType == LUA_TFUNCTION;
    if (callbackType == LUA_TFUNCTION) { clearAllCaches(); syncUnit(L, AURA_UNIT_PLAYER, true); syncUnit(L, AURA_UNIT_TARGET, true); }
    Lua50::PushBool(L, true); Lua50::PushString(L, "OK"); return 2;
}

static int doRefresh(Lua50::State L) {
    const int unit = luaUnitIndex(L, 2);
    if (unit < 0) { Lua50::PushBool(L, false); Lua50::PushString(L, "UNIT_NOT_SUPPORTED"); return 2; }
    syncUnit(L, unit, true); Lua50::PushBool(L, g_ready[unit]); Lua50::PushString(L, g_status[unit]); Lua50::PushNumber(L, (double)g_count[unit]); return 3;
}

static int doGet(Lua50::State L) {
    const int unit = luaUnitIndex(L, 2);
    if (unit < 0 || Lua50::GetTop(L) < 3 || !Lua50::IsNumber(L, 3)) { Lua50::PushNil(L); Lua50::PushString(L, "BAD_ARGUMENT"); return 2; }
    syncUnit(L, unit, false); long slot = (long)Lua50::ToNumber(L, 3);
    if (slot < 0 || slot >= (long)UNIT_AURA_COUNT || !g_cache[unit][slot].spellId) { Lua50::PushNil(L); Lua50::PushString(L, "AURA_NOT_FOUND"); return 2; }
    pushInfo(L, unit, g_cache[unit][slot]); return 1;
}

static int doFind(Lua50::State L) {
    const int unit = luaUnitIndex(L, 2);
    if (unit < 0 || Lua50::GetTop(L) < 3 || !Lua50::IsNumber(L, 3)) { Lua50::PushNil(L); Lua50::PushString(L, "BAD_ARGUMENT"); return 2; }
    const unsigned long spellId = (unsigned long)Lua50::ToNumber(L, 3); syncUnit(L, unit, false);
    for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) if (g_cache[unit][slot].spellId == spellId) { pushInfo(L, unit, g_cache[unit][slot]); return 1; }
    Lua50::PushNil(L); Lua50::PushString(L, "AURA_NOT_FOUND"); return 2;
}

static int doSnapshot(Lua50::State L) {
    const int unit = luaUnitIndex(L, 2);
    if (unit < 0) { Lua50::PushNil(L); Lua50::PushString(L, "UNIT_NOT_SUPPORTED"); return 2; }
    syncUnit(L, unit, false); Lua50::NewTable(L); int arrayIndex = 1;
    for (unsigned long slot = 0; slot < UNIT_AURA_COUNT; ++slot) if (g_cache[unit][slot].spellId) {
        Lua50::PushNumber(L, (double)arrayIndex++); pushInfo(L, unit, g_cache[unit][slot]); Lua50::SetTable(L, -3);
    }
    return 1;
}

bool initialize(Lua50::State L) {
    g_luaState = L; clearAllCaches(); refreshTrackedObjects(); g_nampowerDetected = GetModuleHandleA("nampower.dll") != 0;
    if (g_nampowerDetected) {
        g_mode = MODE_NAMPOWER_EVENTS; g_nampowerEventsRegistered = false;
        copyText(g_modeStatus, sizeof(g_modeStatus), "NAMPOWER_DETECTED_WAITING_FOR_EVENTS"); return true;
    }
    if (g_nativeHooksEnabled) { g_mode = MODE_STANDALONE_NATIVE; return true; }
    if (installNativeHooks()) { g_mode = MODE_STANDALONE_NATIVE; return true; }
    g_mode = MODE_PASSIVE_UNIT_AURA; return true;
}

bool wantsNampowerEvents() { return g_mode == MODE_NAMPOWER_EVENTS; }
void setNampowerEventsRegistered(bool registered) {
    g_nampowerEventsRegistered = registered;
    if (g_mode == MODE_NAMPOWER_EVENTS) copyText(g_modeStatus, sizeof(g_modeStatus), registered ? "NAMPOWER_EVENTS_READY_NO_DUPLICATE_HOOK" : "NAMPOWER_EVENT_REGISTRATION_FAILED_PASSIVE_ONLY");
}

void reset() {
    refreshTrackedObjects();
    clearAllCaches(); copyText(g_status[AURA_UNIT_PLAYER], sizeof(g_status[AURA_UNIT_PLAYER]), "RESET");
    copyText(g_status[AURA_UNIT_TARGET], sizeof(g_status[AURA_UNIT_TARGET]), "RESET");
}

void onEvent(Lua50::State L, const char* eventName, const char* unitToken) {
    if (!eventName) return;
    if (textStarts(eventName, "BUFF_ADDED_") || textStarts(eventName, "BUFF_REMOVED_") || textStarts(eventName, "DEBUFF_ADDED_") || textStarts(eventName, "DEBUFF_REMOVED_")) { handleNampowerEvent(L, eventName); return; }
    if (textEquals(eventName, "UNIT_AURA_GUID")) {
        if (!g_callbackInstalled) return;
        unsigned long isPlayer = 0, isTarget = 0;
        getGlobalNumber(L, "arg2", &isPlayer); getGlobalNumber(L, "arg3", &isTarget);
        const int unit = isTarget ? AURA_UNIT_TARGET : (isPlayer ? AURA_UNIT_PLAYER : -1);
        if (unit >= 0 && syncUnit(L, unit, true)) copyText(g_status[unit], sizeof(g_status[unit]), "READY_UNIT_AURA_GUID");
        return;
    }
    if (textEquals(eventName, "PLAYER_LEAVING_WORLD") || textEquals(eventName, "PLAYER_ENTERING_WORLD")) { reset(); return; }
    if (textEquals(eventName, "PLAYER_TARGET_CHANGED")) {
        refreshTrackedObjects();
        clearUnitCache(AURA_UNIT_TARGET); copyText(g_status[AURA_UNIT_TARGET], sizeof(g_status[AURA_UNIT_TARGET]), "TARGET_CHANGED_WAITING_EVENT"); return;
    }
    if (!textEquals(eventName, "UNIT_AURA")) return;
    if (!g_callbackInstalled) return;
    const int unit = unitIndex(unitToken);
    if (unit >= 0) {
        if (syncUnit(L, unit, true)) copyText(g_status[unit], sizeof(g_status[unit]), "READY_UNIT_AURA");
    } else if (!unitToken || !unitToken[0]) {
        syncUnit(L, AURA_UNIT_PLAYER, true); syncUnit(L, AURA_UNIT_TARGET, true);
    }
}

int dispatch(Lua50::State L, const char* command) {
    if (!command || !textStarts(command, "Aura.")) return -1;
    if (textEquals(command, "Aura.Status")) return doStatus(L);
    if (textEquals(command, "Aura.Mode")) return doMode(L);
    if (textEquals(command, "Aura.SetCallback")) return doSetCallback(L);
    if (textEquals(command, "Aura.Refresh")) return doRefresh(L);
    if (textEquals(command, "Aura.Get")) return doGet(L);
    if (textEquals(command, "Aura.Find")) return doFind(L);
    if (textEquals(command, "Aura.Snapshot")) return doSnapshot(L);
    if (textEquals(command, "Aura.Reset")) { reset(); Lua50::PushBool(L, true); return 1; }
    return -1;
}

const char* mode() {
    if (g_mode == MODE_NAMPOWER_EVENTS) return g_nampowerEventsRegistered ? "NAMPOWER_EVENTS" : "NAMPOWER_PASSIVE";
    if (g_mode == MODE_STANDALONE_NATIVE) return "STANDALONE_NATIVE_HOOK";
    if (g_mode == MODE_PASSIVE_UNIT_AURA) return "PASSIVE_UNIT_AURA";
    return "NOT_INITIALIZED";
}

const char* status() { return g_modeStatus; }
unsigned count() { return g_count[AURA_UNIT_PLAYER] + g_count[AURA_UNIT_TARGET]; }

}
