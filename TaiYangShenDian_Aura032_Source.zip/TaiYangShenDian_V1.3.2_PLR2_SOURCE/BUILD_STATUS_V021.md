# V1.4.1-AURA0.2.1 build status

## Implemented

- Preserved the V1.3.2-PLR2/API 15 compatibility baseline.
- Added automatic Nampower/Standalone dual mode.
- Nampower mode registers the eight `BUFF_*` / `DEBUFF_*` events and installs no duplicate Aura hook.
- Nampower mode also registers `UNIT_AURA_GUID`; its explicit `isTarget` flag drives automatic target poison add/remove/stack callbacks.
- Named-token `UNIT_AURA` remains active as a deduplicated fallback, while unrelated raw-GUID event spam is ignored.
- Standalone mode validates original Build 5875 prologues before installing add/remove/stack hooks.
- Unknown pre-existing entry modification produces `PASSIVE_UNIT_AURA`, never an overwrite.
- Corrected UnitFields pointer, Aura IDs, packed flags, levels and stack offsets.
- Corrected zero-based stored applications to one-based displayed stack count.
- Added `Aura.Mode` and `Aura.Find` while retaining every v0.1.1 command.
- Added DreamWeapon-style `TaiYangAura` companion/diagnostic addon with custom spell-ID filtering.
- No worker thread, timer, addon `OnUpdate`, per-frame scan or new render hook.

## Build verification

- GitHub Actions run: `32813617414` (`success`)
- File: `taiyangshendian.dll`
- Size: `250880` bytes
- SHA-256: `c39e26c76183c3fdb4ed6949d31a474ee6663cb4908b4acd71b276021f29eff5`
- PE32 / Intel i386: PASS
- Windows subsystem 5.01: PASS
- Deterministic PE timestamp 0: PASS
- Imports: `KERNEL32.dll` only
- Exports retained: `FirstEnterWorld`, `Load`, `TaiYangShenDianNativeStatus`, `_DllMain@12`
- Dual-mode / `UNIT_AURA_GUID` / version strings present: PASS

Real-machine acceptance inside Turtle WoW remains required before Stable freeze.
