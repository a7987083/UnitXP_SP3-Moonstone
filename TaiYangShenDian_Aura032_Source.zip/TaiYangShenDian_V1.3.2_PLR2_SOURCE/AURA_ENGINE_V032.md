# TaiYangShenDian AuraEngine v0.3.2

Paired DLL: `1.4.4-AURA0.3.2`, API 15.

## Native event dispatch

The previous standalone Aura hooks called the registered Lua function directly. Version 0.3.2 instead uses WoW's native `SignalEventParam` dispatcher, the same event-delivery mechanism used by Nampower.

1. The add/remove/stack hook calls the original client function.
2. It identifies player/target from cached object pointers.
3. It reads only the changed slot when add/stack requires the current level and application count; removal uses the hook parameters directly.
4. It emits standard event ID 41 (`UNIT_AURA`) with marker `TYS_AURA` and the exact payload.
5. TaiYangAura handles that one event and updates the UI once.

There is no OnUpdate, timer, polling, dirty pump, automatic `Aura.Find`, or automatic 48-slot traversal. Manual Apply/Verify snapshots remain available only on explicit user action.
