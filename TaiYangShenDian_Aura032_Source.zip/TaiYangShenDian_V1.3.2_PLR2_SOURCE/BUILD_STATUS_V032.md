# V1.4.4-AURA0.3.2 build status

- Target: 32-bit Windows PE DLL for WoW 1.12.1 build 5875.
- API version: 15.
- Build ID: `20260825-v144-aura032-native-event-dispatch`.
- Standalone Hook: native `UNIT_AURA` event dispatch with exact changed-slot payload.
- Idle behavior: no Lua work, no polling, no automatic Aura scan.
- Nampower mode: direct Lua single channel retained.
