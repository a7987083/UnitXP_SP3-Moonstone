# V1.4.2-AURA0.3.0 build status

- Target: 32-bit Windows PE DLL for WoW 1.12.1 build 5875.
- API version: 15 (compatible with the previous package).
- Build ID: `20260825-v142-aura030-nampower-target-guid`.
- Source change: Nampower target GUID comparison now uses `GetUnitGUID("target")` first.
- Hook policy: no duplicate Aura hooks while Nampower is loaded.
- Companion addon: TaiYangAura 0.3.0 direct Nampower event path plus DLL callback fallback.

GitHub Actions produces the authoritative binary and SHA-256 manifest.
